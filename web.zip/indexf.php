<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BMIIT | Babu Madhav Institute Of Information Technology</title>
    <link rel="icon" type="image/ico" href="Bm.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>

    <style>

    p{
      color: black;
      font-size: 20px;
    }   

    body{
      background-color: #f2f2f2;
    } 

    /*footer{
      width: 1150px;
      margin-top: 30px;
    }*/
    </style>

  </head>
  <body>
    
    <nav class="navbar navbar-expand-lg bg-light navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">BMIIT</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="indexf.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="about.php">About</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><b>
            Student Corner</b>
          </a>
          <ul class="dropdown-menu">
            <!-- <li><a class="dropdown-item" aria-current="page" href="#">Bsc(IT)</a></li>
            <li><a class="dropdown-item" aria-current="page"href="#">Msc(IT)</a></li>
            <li><a class="dropdown-item" aria-current="page" href="#">Magazine</a></li>
            <li><a class="dropdown-item" aria-current="page" href="index1.php">SIS</a></li>
            <li><a class="dropdown-item" aria-current="page" href="#">NSS</a></li> -->
            <li><a class="dropdown-item" aria-current="page" href="reg.php">Registration</a></li>
            <li><a class="dropdown-item" aria-current="page" href="login.php">Login</a></li>

          </ul>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">placement</a>
        </li> -->
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="contact.php">Contact Us</a>
        </li>

        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="logout.php">Logout</a>
        </li>

      </ul>
    <!--  <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-danger" type="submit">Search</button>
      </form> -->
    </div>
  </div>
</nav>

											<!--  Image  Slider  -->


        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="B1.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="B2.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="B3.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
							
									<!--  Content -->

                  <br>
                  <br>

			<h1 style=" text-align: center; text-shadow: 2px 2px gray; ">Babu Madhav Institute of Information Technology</h1><br>
      <br>
      <br>

      <div class="container text-center">
          <div class="row">
            <div class="col">
              <h3>MISSION</h3>
              <p>To remain on the cutting edge of education, research and service to industry, society and students.</p>
              </div>  

          <div class="col">
              <h3>VISION</h3>
              <p>To become a globally recognized premier educational pilgrimage for its excellence in academics.
                - To create and sustain professional research and knowledge based services to academic and community.</p>
              </div>
        </div>
    <br>
    <br>
    


    <h1 style="text-align: center;">WELCOME TO BMIIT</h1>
    <br>
    <br>

    <p>Babu Madhav Institute of Information Technology, popularly known as BMIIT is premier institute of Uka Tarsadia University which offers two courses of Three Years Bachelor of Science in Information Technology B.Sc. (IT) and Five Years Integrated Masters of Science in Information Technology; and named after its beloved donor respected Shri Babubhai Madhavbhai Patel a great human being and renowned businessman from USA.</p>
<p>At BMIIT we focus on holistic development of student. We not only insist on academic growth of the students but we cultivate moral values and ethics among them which help them to lead a successful life, both professional and personal. The same can be reflected in the tagline of BMIIT - Make it happen through innovation and values.</p>
<p>At BMIIT we are following an advanced curriculum, and again it is updated time to time according to the demanding needs of the IT industry. By adhering to the UGC standards of curriculum, we at BMIIT follows CBCS (Choice Based Credit System) based curriculum whilst incorporating subjects that result into holistic academic curriculum.</p>
<p>BMIIT is furnished with state of the art infrastructure. All class rooms are equipped with projector, Wi-Fi access. Laboratories are also equipped with around 200 high configuration computers and audio visual tools to provide better learning environment.</p><br><br>

  <h1>RECENT EVENT</h1>
  <br>
  <br>
  <br>

  <div class="container-fluid text-center">
  <div class="row">
    <div class="col">
       <img src="A1.jpg" width="300" height="300">
              <p></p>
              <h3>CREATIVE INSTITUTE AWARD 2021 BY IFEHE, NCAT 2021</h3><br>
                <p>BMIIT received "Creative Institute Award 2021" by International Forum for Excellence in Higher Education (IFEHE), National Creativity Aptitude Test among 198 Institutes and 122 Cities.</p>
    </div>
    <div class="col">
      <img src="A2.jpg" width="300" height="300">
              <p></p>
              <h3>ALL INDIA RANK, IN NCAT 2021</h3>
              <p>Ms. Isha Motiyani, student of BMIIT secured All India Rank 7 in category 2 of National Creativity Aptitude Test 2021.</p>
    </div>
    <div class="col">
      <img src="A3.jpg" width="300" height="300">
              <p></p>
              <h3>IGNITE 2019, CHARUSAT, CHANGA</h3>
              <p>CMPICA, CHARUSAT University, Changa organized IGNITE 2019 on 14th February 2019.</p>
    </div>
  </div>
</div>
           <!--    <br>
              <br>
              <br>
              <br>
 
              <hr> 
              <br>
              <br> -->

<!-- <div class="container text-center">
  <div class="row">
    <div class="col">
       <a href="https://www.facebook.com/mscitdcstutu?fref=ts"><img src="fb.png" width="95" height="95"></a>
    </div>
    <div class="col">
     <a href="https://www.instagram.com/bmiit.utu/?hl=en"> <img src="ins.png" width="95" height="95"></a>
    </div>
    <div class="col">
      <a href="director.bmiit@utu.ac.in"><img src="Gm.png" width="95" height="95"></a>
    </div>
  </div>
</div> -->
        <br>
        <br>
        <br>
        <br>    
        <br>


     </div>                         <!-- Footer -->

<!-- Remove the container if you want to extend the Footer to full width. -->
<!-- <div class="container my-5"> -->

  <footer class="bg-dark text-center text-white">
  <!-- Grid container -->
  <!-- <div class="container p-10"> -->
    <!-- Section: Social media -->
    <section class="">
      <!-- Facebook -->
      <a class="btn btn-outline btn-floating m-1" href="https://www.facebook.com/mscitdcstutu?fref=ts" role="button"
        ><i class="fab fa-instagram"><img src="fb2.png" height="37"></i
      ></a>

      <!-- Twitter -->
      <a class="btn btn-outline btn-floating m-1" href="https://twitter.com/mscitinbmiit?lang=en" role="button"
        ><i class="fab fa-instagram"><img src="tw.png" height="47"></i
      ></a>

      <!-- Google -->
      <a class="btn btn-outline btn-floating m-1" href="https://www.google.com/search?client=opera-gx&q=bmiit&sourceid=opera&ie=UTF-8&oe=UTF-8" role="button"
        ><i class="fab fa-instagram"><img src="goo.png" height="55"></i
      ></a>

      <!-- Instagram -->
      <a class="btn btn-outline btn-floating m-1" href="https://www.instagram.com/bmiit.utu/?hl=en" role="button"
        ><i class="fab fa-instagram"><img src="ins.png" height="30"></i
      ></a>

      <!-- Linkedin -->
      <a class="btn btn-outline btn-floating m-1" href="https://www.linkedin.com/in/bmiit-utu-090858185/?originalSubdomain=in" role="button"
        ><i class="fab fa-instagram"><img src="li.png" height="30"></i
      ></a>

    </section>
    <!-- Section: Social media -->
  <!-- </div> -->
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center py-2" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2022 Design by Dev Solanki 
   
  </div>
  <!-- Copyright -->
</footer>
  
<!-- </div> -->
<!-- End of .container -->

<script>
  // alert("WELCOME TO BMIIT");
  // document.write("Dev solanki");
  //console.log("Dev Solanki");

  // variable in javascript
  
  var a = "Dev solanki";
  var b = 10;
  var c = 20;
  console.log(a,b);  // Output is = 0 'Dev solanki'

  // Operators and its operations

  console.log(b*c);   // Output is = 200
  console.log(b+c);   // Output is = 30
  console.log(b-c);   // Output is = -10
  console.log(++b);   // Output is = 11

  var len = a.length;
  console.log(len);  //  Output = Dev solanki 10

</script> 

</body>
</html>
