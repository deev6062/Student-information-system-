<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Contact Us</title>
  <link rel="icon" type="image/ico" href="bm.png">
  <link rel='stylesheet' href='https://fonts.googleapis.com/css?family=Rubik:400,700'> <link rel="stylesheet" href="style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>



</head>
<body>

  <nav class="navbar navbar-expand-lg bg-light navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="indexf.php">BMIIT</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="indexf.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="about.php">About</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false"><b>
            Student Corner</b>
          </a>
          <ul class="dropdown-menu">
         <!--    <li><a class="dropdown-item" aria-current="page" href="#">Bsc(IT)</a></li>
            <li><a class="dropdown-item" aria-current="page"href="#">Msc(IT)</a></li>
            <li><a class="dropdown-item" aria-current="page" href="#">Magazine</a></li>
            <li><a class="dropdown-item" aria-current="page" href="index1.php">SIS</a></li>
            <li><a class="dropdown-item" aria-current="page" href="#">NSS</a></li> -->
            <li><a class="dropdown-item" aria-current="page" href="reg.php">Registration</a></li>
            <li><a class="dropdown-item" aria-current="page" href="login.php">Login</a></li>
          </ul>
        </li>
        <!-- <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">placement</a>
        </li> -->
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="contact.php">Contact Us</a>
        </li>
      </ul>
    </div>
  </div>
</nav>


                                        <!-- Content -->



<div class=" text-center">
  <div class="card-header">
    <br><br><h3 style="text-align: center;">Contact Us</h3><br><hr><br><br>
    <img src="Bm.png"><br><br><br>
    <p>Babu Madhav Institute Of Information Technology,</p>
    <p>Maliba Campus,</p>
    <p>Gopal Vidyanagar,</p>
    <p>Bardoli Mahuva Road, Tarsadi.</p>
    <p>Dist: Surat - 394 350,</p>
    <p>Gujarat (INDIA).</p>
    <p>+91 2622 290562</p>
    <p> Dr. Jitendra Nasriwala, 9825518405</p>
    <p> Mr. Sandip Delwadkar, 9328719610</p>
    <p> Mr. Hardik Vyas, 9825658143</p>
    <p> Mr. Sapan Naik, 9586113399</p>
    <p>director.bmiit@utu.ac.in</p><br>
  </div>
</div>


    </div>                         <!-- Footer -->

<!-- Remove the container if you want to extend the Footer to full width. -->
<!-- <div class="container my-5"> -->

  <footer class="bg-dark text-center text-white">
  <!-- Grid container -->
  <!-- <div class="container p-10"> -->
    <!-- Section: Social media -->
    <section class="">
      <!-- Facebook -->
      <a class="btn btn-outline btn-floating m-1" href="https://www.facebook.com/mscitdcstutu?fref=ts" role="button"
        ><i class="fab fa-instagram"><img src="fb2.png" height="37"></i
      ></a>

      <!-- Twitter -->
      <a class="btn btn-outline btn-floating m-1" href="https://twitter.com/mscitinbmiit?lang=en" role="button"
        ><i class="fab fa-instagram"><img src="tw.png" height="47"></i
      ></a>

      <!-- Google -->
      <a class="btn btn-outline btn-floating m-1" href="https://www.google.com/search?client=opera-gx&q=bmiit&sourceid=opera&ie=UTF-8&oe=UTF-8" role="button"
        ><i class="fab fa-instagram"><img src="goo.png" height="55"></i
      ></a>

      <!-- Instagram -->
      <a class="btn btn-outline btn-floating m-1" href="https://www.instagram.com/bmiit.utu/?hl=en" role="button"
        ><i class="fab fa-instagram"><img src="ins.png" height="30"></i
      ></a>

      <!-- Linkedin -->
      <a class="btn btn-outline btn-floating m-1" href="https://www.linkedin.com/in/bmiit-utu-090858185/?originalSubdomain=in" role="button"
        ><i class="fab fa-instagram"><img src="li.png" height="30"></i
      ></a>

    </section>
    <!-- Section: Social media -->
  <!-- </div> -->
  <!-- Grid container -->

  <!-- Copyright -->
  <div class="text-center py-2" style="background-color: rgba(0, 0, 0, 0.2);">
    © 2022 Design by Dev Solanki 
   
  </div>
  <!-- Copyright -->
</footer>
  
<!-- </div> -->
<!-- End of .container -->

</body>
</html>
