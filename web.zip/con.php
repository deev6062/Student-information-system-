
<?php
// Step 4: Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "siss";

$conn = new mysqli($localhost, $root, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Step 5: Retrieve form data
$fname = $_POST['fname'];
$enrollmentno = $_POST['enro'];
$course = $_POST['course'];
$gender = $_POST['gender'];
$dob = $_POST['dob'];
$password = $_POST['password'];

// Step 6: Prepare and execute the SQL query
$stmt = $conn->prepare("INSERT INTO registration (fname, enrollmentno, course, gender, dob, password) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $fname, $enrollmentno, $course, $gender, $dob, $password);
$stmt->execute();

// Step 7: Handle success or failure
if ($stmt->affected_rows > 0) {
    echo "Data saved successfully!";
} else {
    echo "Error saving data: " . $conn->error;
}

$stmt->close();
$conn->close();
?>




